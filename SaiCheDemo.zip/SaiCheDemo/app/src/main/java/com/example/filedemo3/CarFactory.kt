package com.example.filedemo3

object CarFactory {
    private val brands = listOf("Toyota", "Ford", "BMW", "Audi", "Honda")
    private val models = listOf("Car A", "Car B", "Car C", "Car D", "Car E")
    private val driveTypes = listOf("Front-Wheel Drive", "Rear-Wheel Drive", "All-Wheel Drive")
    private val carTypes = listOf("Crossover", "Sedan", "Truck", "SportsCar")

    fun createRandomCar(): Car {
        val brand = brands.random()
        val model = models.random()
        val year = (2000..2023).random()
        val driveType = driveTypes.random()
        val additionalField = (100..500).random()
        val carType = carTypes.random()

        return AutoBuilder(brand, model)
            .setYear(year)
            .setDriveType(driveType)
            .setAdditionalField(additionalField)
            .setCarType(carType)
            .build()
    }
}