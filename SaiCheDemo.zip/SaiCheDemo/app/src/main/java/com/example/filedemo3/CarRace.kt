package com.example.filedemo3

object CarRace {
    fun race(car1: Car, car2: Car): Car {
        val car1Score = car1.year + car1.model.length + when (car1) {
            is Crossover -> car1.enginePower
            is Sedan -> car1.luxuryLevel
            is Truck -> car1.loadCapacity
            is SportsCar -> car1.topSpeed
            else -> 0
        }

        val car2Score = car2.year + car2.model.length + when (car2) {
            is Crossover -> car2.enginePower
            is Sedan -> car2.luxuryLevel
            is Truck -> car2.loadCapacity
            is SportsCar -> car2.topSpeed
            else -> 0
        }

        return if (car1Score > car2Score) car1 else car2
    }
}