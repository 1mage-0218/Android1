package com.example.filedemo3

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etCarCount: EditText = findViewById(R.id.etCarCount)
        val btnStartRace: Button = findViewById(R.id.btnStartRace)

        btnStartRace.setOnClickListener {
            val carCount = etCarCount.text.toString().toIntOrNull() ?: return@setOnClickListener
            val cars = List(carCount) { CarFactory.createRandomCar() }
            startRace(cars)
        }
    }

    private fun startRace(cars: List<Car>) {
        var currentRoundCars = cars.toMutableList()
        while (currentRoundCars.size > 1) {
            val nextRoundCars = mutableListOf<Car>()
            currentRoundCars.shuffle()
            for (i in 0 until currentRoundCars.size step 2) {
                if (i + 1 < currentRoundCars.size) {
                    val winner = CarRace.race(currentRoundCars[i], currentRoundCars[i + 1])
                    println("Race between ${currentRoundCars[i].model} and ${currentRoundCars[i + 1].model}, winner is ${winner.model}")
                    Log.e("data","Race between ${currentRoundCars[i].model} and ${currentRoundCars[i + 1].model}, winner is ${winner.model}")
                    nextRoundCars.add(winner)
                } else {
                    println("${currentRoundCars[i].model} has no opponent and moves to the next round")
                    Log.e("data","${currentRoundCars[i].model} has no opponent and moves to the next round")
                    nextRoundCars.add(currentRoundCars[i])
                }
            }
            currentRoundCars = nextRoundCars
        }

        println("The overall winner is ${currentRoundCars.first().model}")
        Log.e("data","The overall winner is ${currentRoundCars.first().model}")
    }


}
