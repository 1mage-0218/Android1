package com.example.filedemo3

open class Car(
    val brand: String,
    val model: String,
    val year: Int,
    val driveType: String
) {
    open fun displayInfo() {
        println("Brand: $brand, Model: $model, Year: $year, Drive Type: $driveType")
    }
}

class Crossover(
    brand: String,
    model: String,
    year: Int,
    driveType: String,
    val enginePower: Int
) : Car(brand, model, year, driveType) {
    override fun displayInfo() {
        super.displayInfo()
        println("Engine Power: $enginePower")
    }
}

class Sedan(
    brand: String,
    model: String,
    year: Int,
    driveType: String,
    val luxuryLevel: Int
) : Car(brand, model, year, driveType) {
    override fun displayInfo() {
        super.displayInfo()
        println("Luxury Level: $luxuryLevel")
    }
}

class Truck(
    brand: String,
    model: String,
    year: Int,
    driveType: String,
    val loadCapacity: Int
) : Car(brand, model, year, driveType) {
    override fun displayInfo() {
        super.displayInfo()
        println("Load Capacity: $loadCapacity")
    }
}

class SportsCar(
    brand: String,
    model: String,
    year: Int,
    driveType: String,
    val topSpeed: Int
) : Car(brand, model, year, driveType) {
    override fun displayInfo() {
        super.displayInfo()
        println("Top Speed: $topSpeed")
    }
}