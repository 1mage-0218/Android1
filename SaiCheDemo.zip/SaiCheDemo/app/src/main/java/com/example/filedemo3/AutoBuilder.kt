package com.example.filedemo3

class AutoBuilder(
    private var brand: String,
    private var model: String
) {
    private var year: Int = 2023
    private var driveType: String = "Front-Wheel Drive"
    private var additionalField: Int = 100
    private var carType: String = "Crossover"

    fun setYear(year: Int) = apply { this.year = year }
    fun setDriveType(driveType: String) = apply { this.driveType = driveType }
    fun setAdditionalField(value: Int) = apply { this.additionalField = value }
    fun setCarType(carType: String) = apply { this.carType = carType }

    fun build(): Car {
        return when (carType) {
            "Crossover" -> Crossover(brand, model, year, driveType, additionalField)
            "Sedan" -> Sedan(brand, model, year, driveType, additionalField)
            "Truck" -> Truck(brand, model, year, driveType, additionalField)
            "SportsCar" -> SportsCar(brand, model, year, driveType, additionalField)
            else -> throw IllegalArgumentException("Unknown car type")
        }
    }
}